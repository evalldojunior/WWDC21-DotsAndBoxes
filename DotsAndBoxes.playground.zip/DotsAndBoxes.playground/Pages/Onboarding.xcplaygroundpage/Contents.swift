/*:
 
 # Dots and Boxes
 
 Welcome to my playground! :)
 
 Dots and Boxes is a **multiplayer** game where it has mechanisms that develop the logical, strategic and deductive reasoning of players through challenges with friends and family, allowing people to get closer through fun and a playful activity.
 
 [The Game ](TheGame)
 [/ About Me ](AboutMe)
 [/ Credits](Credits)

 ***Run the code to see the onboarding and learn how it works.***
 
 ---
 */
import PlaygroundSupport
import SwiftUI

/// Fonts
let regular = Bundle.main.url(forResource: "Raleway-Regular", withExtension: "ttf")! as CFURL
let bold = Bundle.main.url(forResource: "Raleway-Bold", withExtension: "ttf")! as CFURL
let bebas = Bundle.main.url(forResource: "BebasNeue-Regular", withExtension: "ttf")! as CFURL
let semiBold = Bundle.main.url(forResource: "Raleway-SemiBold", withExtension: "ttf")! as CFURL
CTFontManagerRegisterFontsForURL(regular, CTFontManagerScope.process, nil)
CTFontManagerRegisterFontsForURL(bold, CTFontManagerScope.process, nil)
CTFontManagerRegisterFontsForURL(bebas, CTFontManagerScope.process, nil)
CTFontManagerRegisterFontsForURL(semiBold, CTFontManagerScope.process, nil)

/// Onboarding
var onboarding = Onboarding()
var view = OnboardingMainPage().environmentObject(onboarding)
PlaygroundPage.current.setLiveView(view)

/*:
 ---
 
 ***Please try the game!.  ->***
 [Game Page](@next)
 
 */
