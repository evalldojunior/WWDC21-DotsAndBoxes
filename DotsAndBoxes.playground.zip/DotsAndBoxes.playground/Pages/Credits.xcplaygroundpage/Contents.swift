/*:
 
 # Dots and Boxes
 
 ## Credits
 
 All sounds was not created by me. I will give due credit to the authors of the sounds. Thank you,
 - Pause Sound: [GameAudio on Freesound](https://freesound.org/people/GameAudio/sounds/220190/)
 - Box Sound: [InspectorJ on Freesound](https://freesound.org/people/InspectorJ/sounds/403009/)
 - Win Sound: [Mixkit](https://mixkit.co/free-sound-effects/win/)
 - Tap Sound: [Mixkit](https://mixkit.co/free-sound-effects/pop/)
 - Discovered Sound: [Mixkit](https://mixkit.co/free-sound-effects/sparkle/)
 - Extra Life Sound: [Mixkit](https://mixkit.co/free-sound-effects/tap/)
 
 
 
 All custom font was not created by me. I leave available here the places where I downloaded the fonts. Thank you,
 - Raleway: [The League of Moveable Type on Font Squirrel](https://www.fontsquirrel.com/fonts/raleway)
 - Bebas Neue: [Flat-it on Font Squirrel](https://www.fontsquirrel.com/fonts/bebas-neue)
 
 
 ---
 */
/*:
 ---
 [Onboarding ](Onboarding)
 [/ The Game](TheGame)
 [/ About Me](Credits)
 
 */
