/*:
 
 # Dots and Boxes
 ## The Game
 Dots and Boxes is a **multiplayer** game, so please find your **player 2**.
 \
 &nbsp;
 
 ## How does it work?
 
 ### Original Game
 - Dots and Boxes displays an empty arena for people to battle against each other to conquer the **boxes**.
 - Two players take turns to connect the **dots**.
 - A player who completes the fourth side of a 1×1 **box** earns the **box** and takes another turn.
 - **The goal is to conquer as many boxes as possible.**
 
 
 ### Additions
 - **Timer**: In order to make faster moves. Tic Tac Tic Tac.
 - **Extra Life**: In case your time runs out, but be careful.
 \
 &nbsp;

 ***Run the code to start the game.***
 
 ---
 */
import PlaygroundSupport
import SwiftUI

/// Fonts
let regular = Bundle.main.url(forResource: "Raleway-Regular", withExtension: "ttf")! as CFURL
let bold = Bundle.main.url(forResource: "Raleway-Bold", withExtension: "ttf")! as CFURL
let bebas = Bundle.main.url(forResource: "BebasNeue-Regular", withExtension: "ttf")! as CFURL
let semiBold = Bundle.main.url(forResource: "Raleway-SemiBold", withExtension: "ttf")! as CFURL
CTFontManagerRegisterFontsForURL(regular, CTFontManagerScope.process, nil)
CTFontManagerRegisterFontsForURL(bold, CTFontManagerScope.process, nil)
CTFontManagerRegisterFontsForURL(bebas, CTFontManagerScope.process, nil)
CTFontManagerRegisterFontsForURL(semiBold, CTFontManagerScope.process, nil)

/*:
 ---
\
 ***You can change the attributes below to customize your game!***
 */
/// user inputs
// Names
let player1Name = "gustavo"
let player2Name = "junior"

// Colors
// select the color following the example below
let player1Color = Color(UIColor.systemTeal)
let player2Color = Color(UIColor.systemIndigo)
  
  
// The arena is a square matrix of order n (n-square matrix)
// this playgrounds accepts 3 <= n <= 9 for better results
let n = 9
  
  
PlaygroundPage.current.setLiveView(GameView(player1Name: player1Name, player2Name: player2Name, player1Color: player1Color, player2Color: player2Color, nOrder: n))

/*:
 ---
 [Onboarding ](TheGame)
 [/ About Me ](AboutMe)
 [/ Credits](Credits)
 
 */
