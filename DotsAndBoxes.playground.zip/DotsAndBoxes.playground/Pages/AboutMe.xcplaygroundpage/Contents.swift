/*:
 
 # Dots and Boxes
 
 ## About Me
 
 Hey! My name is Evaldo Garcia de Souza Júnior and  I'm 23 years old. I am a Computer Science student at the Federal University of Pernanbuco - Brazil. I am also a student at the Apple Developer Academy and I'am currently deeply studying SwiftUI and I am loving it!

 Developing this playground in SwiftUI made it possible to accomplish a lot of knowledge that I have been in contact with and experienced at the Academy. I hope you enjoy the playground!
 
 \
 &nbsp;
 
 ![Playground icon](EvaldoJunior.jpg)
 ---
 */
/*:
 ---
 [Onboarding ](Onboarding)
 [/ The Game](TheGame)
 [/ Credits](Credits)
 
 */
